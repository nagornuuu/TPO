package zad1;

public class PeriodFormatter {
}
